package com.aquasense.ui.onboarding

class OnBoardingData (var title: String, var desc: String, var imageUrl: Int) {
}