package com.aquasense.ui.perkiraancuaca.model

data class PerkiraanCuacaDetail(
    val waktu: String,
    val kondisiCuaca: String
)