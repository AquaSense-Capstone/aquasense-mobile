package com.aquasense.ui.perkiraancuaca.model

data class PerkiraanCuaca(
    val kota: String,
    val kondisiCuacaPagi: String,
    val kondisiCuacaSiang: String,
    val kondisiCuacaSore: String,
    val kondisiCuacaMalam: String
)