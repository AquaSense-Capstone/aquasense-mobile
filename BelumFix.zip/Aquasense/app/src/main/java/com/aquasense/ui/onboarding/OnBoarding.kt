package com.aquasense.ui.onboarding

class OnBoarding {
}